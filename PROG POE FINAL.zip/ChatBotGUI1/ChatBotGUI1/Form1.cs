using Figgle;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Media;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CyberGuardianGUI1
{
    public partial class Form1 : Form
    {
        // ----- DATA STRUCTURES -----
        private List<CyberTask> TaskList = new List<CyberTask>();
        private List<string> ActivityLog = new List<string>();
        private Random rand = new Random();
        private string currentTopic = null;
        private Dictionary<string, string> userMemory = new Dictionary<string, string>();

        // Responses dictionaries
        private Dictionary<string, string> responses = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            { "how are you", "I'm a bot, but I'm fully operational and ready to help you stay safe online!" },
            { "what's your purpose", "My mission is to educate and empower you with cybersecurity knowledge." },
            { "what can i ask you about", "You can ask me about password safety, phishing, safe browsing, and general cybersecurity tips." },
            { "safe browsing", "Avoid clicking unknown links, use HTTPS websites, and keep your browser up to date." }
        };

        private Dictionary<string, string> keywordResponses = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            { "password", "Make sure to use strong, unique passwords for each account. Consider using a password manager." },
            { "scam", "Watch out for online scams. If something sounds too good to be true, it probably is." },
            { "privacy", "Protect your privacy by limiting what you share online and reviewing app permissions regularly." }
        };

        private Dictionary<string, List<string>> topicResponses = new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase)
        {
            {
                "phishing", new List<string>
                {
                    "Watch out for emails with urgent requests or attachments.",
                    "Always verify the sender's email address before clicking links.",
                    "Don�t enter credentials on suspicious login pages.",
                    "Phishing often mimics trusted brands�double-check URLs.",
                    "Enable 2FA to protect accounts even if your password is phished."
                }
            },
            {
                "password safety", new List<string>
                {
                    "Use a mix of letters, numbers, and symbols in your passwords.",
                    "Avoid using the same password across multiple sites.",
                    "Consider using a trusted password manager.",
                    "Change your passwords regularly, especially after a breach."
                }
            }
        };

        private Dictionary<string, string> sentimentResponses = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            { "worried", "It's completely understandable to feel that way. Remember, staying informed helps you stay safe!" },
            { "frustrated", "I know cybersecurity can be challenging. I'm here to help you step-by-step." },
            { "curious", "That's great! Curiosity is the first step toward becoming cybersecurity savvy." }
        };

        // ----- FORM CONSTRUCTOR -----
        public Form1()
        {
            InitializeComponent();

            // Just show a simple welcome message without delay or ASCII art
            chatBox.AppendText("CyberGuardian: Welcome! Your AI Guide to Cybersecurity.\n");

            ShowWelcomeMessage();
        }


        // ----- UI HANDLERS -----
        private async void btnSend_Click(object sender, EventArgs e)
        {
            string input = txtInput.Text.Trim();
            if (string.IsNullOrWhiteSpace(input))
                return;

            AppendText($"You: {input}", Color.LightBlue);
            txtInput.Clear();

            await ProcessUserInput(input);
        }

        private async Task ProcessUserInput(string input)
        {
            string inputLower = input.ToLower();

            if (inputLower == "exit")
            {
                AppendText("CyberGuardian: Session ended. Stay safe!", Color.Green);
                btnSend.Enabled = false;
                txtInput.Enabled = false;
                return;
            }

            if (inputLower == "show activity log" || inputLower == "what have you done for me?" || inputLower == "show my actions" || inputLower == "task summary")
            {
                ShowActivityLog();
                return;
            }

            if (inputLower.Contains("start quiz") || inputLower.Contains("cyber quiz") || inputLower.Contains("quiz game") || inputLower.Contains("quiz"))
            {
                LogAction("Quiz started.");
                await StartCyberQuiz();
                LogAction("Quiz completed.");
                return;
            }

            if (inputLower.StartsWith("add task") || inputLower.StartsWith("add a task") || inputLower.Contains("create task"))
            {
                string taskTitle = ExtractTaskTitle(inputLower);
                if (!string.IsNullOrWhiteSpace(taskTitle))
                {
                    await AddTaskFlow("add task - " + taskTitle);
                    LogAction($"Added task via NLP command: '{taskTitle}'");
                }
                else
                {
                    AppendText("CyberGuardian: Please specify the task title after 'add task'. For example, 'Add task - update password'.", Color.Red);
                }
                return;
            }

            if (inputLower.Contains("show tasks") || inputLower.Contains("list tasks") || inputLower.Contains("my tasks"))
            {
                ShowTasks();
                LogAction("Displayed task list.");
                return;
            }

            if (inputLower.Contains("remind me to") || inputLower.Contains("add a reminder to"))
            {
                HandleAddReminder(input);
                LogAction($"Added reminder via NLP command: '{input}'");
                return;
            }

            if (inputLower.Contains("phishing"))
            {
                currentTopic = "phishing";
                string tip = topicResponses[currentTopic][rand.Next(topicResponses[currentTopic].Count)];
                AppendText($"CyberGuardian: Here's a tip on phishing: {tip}", Color.Green);
                LogAction("Provided phishing tip.");
                return;
            }

            // Sentiment detection
            foreach (var sentiment in sentimentResponses)
            {
                if (inputLower.Contains(sentiment.Key))
                {
                    AppendText($"CyberGuardian: {sentiment.Value}", Color.Green);
                    LogAction($"Handled sentiment expression: '{sentiment.Key}'");
                    return;
                }
            }

            // Interest detection
            if (inputLower.StartsWith("i'm interested in ") || inputLower.StartsWith("i am interested in "))
            {
                string interest = input.Substring(input.IndexOf("in ") + 3).Trim();
                userMemory["interest"] = interest;
                AppendText($"CyberGuardian: Great! I'll remember that you're interested in {interest}.", Color.Green);
                currentTopic = interest.ToLower();
                LogAction($"User interest noted: {interest}");
                return;
            }

            // Personalized tips
            if (userMemory.ContainsKey("interest") && inputLower.Contains("tip"))
            {
                string interest = userMemory["interest"];
                AppendText($"CyberGuardian: As someone interested in {interest}, here's a tip:", Color.Green);

                if (topicResponses.ContainsKey(interest.ToLower()))
                {
                    string personalizedTip = topicResponses[interest.ToLower()][rand.Next(topicResponses[interest.ToLower()].Count)];
                    AppendText($"CyberGuardian: {personalizedTip}", Color.Green);
                    LogAction($"Provided personalized tip for interest: {interest}");
                }
                else if (keywordResponses.ContainsKey(interest.ToLower()))
                {
                    AppendText($"CyberGuardian: {keywordResponses[interest.ToLower()]}", Color.Green);
                    LogAction($"Provided keyword tip for interest: {interest}");
                }
                else
                {
                    AppendText("CyberGuardian: I don't have specific tips on that yet, but I�ll remember it for the future!", Color.Green);
                    LogAction($"No tip available for interest: {interest}");
                }
                currentTopic = interest.ToLower();
                return;
            }

            // More explanation on current topic
            if (currentTopic != null && (inputLower.Contains("more") || inputLower.Contains("explain") || inputLower.Contains("i don't understand") || inputLower.Contains("what do you mean") || inputLower.Contains("huh") || inputLower.Contains("i'm confused")))
            {
                if (topicResponses.ContainsKey(currentTopic))
                {
                    string nextTip = topicResponses[currentTopic][rand.Next(topicResponses[currentTopic].Count)];
                    AppendText($"CyberGuardian: Here's more on {currentTopic}: {nextTip}", Color.Green);
                    LogAction($"Provided follow-up explanation for topic: {currentTopic}");
                    return;
                }
            }

            // Static responses
            if (responses.TryGetValue(inputLower, out string staticResponse))
            {
                AppendText($"CyberGuardian: {staticResponse}", Color.Green);
                LogAction($"Responded with static response for: '{inputLower}'");
                currentTopic = null;
                return;
            }

            // Topic responses
            if (topicResponses.TryGetValue(inputLower, out List<string> topicList))
            {
                string randomResponse = topicList[rand.Next(topicList.Count)];
                AppendText($"CyberGuardian: {randomResponse}", Color.Green);
                LogAction($"Provided topic response for: '{inputLower}'");
                currentTopic = inputLower;
                return;
            }

            // Keyword check
            foreach (var pair in keywordResponses)
            {
                if (inputLower.Contains(pair.Key))
                {
                    AppendText($"CyberGuardian: {pair.Value}", Color.Green);
                    LogAction($"Provided keyword response for: '{pair.Key}'");
                    currentTopic = pair.Key;
                    return;
                }
            }

            // Default fallback
            AppendText("CyberGuardian: I'm not sure I understand. Can you try rephrasing?", Color.Red);
            LogAction($"Unrecognized input: '{inputLower}'");
            currentTopic = null;
        }

        // ----- TASKS & REMINDERS -----
        private string ExtractTaskTitle(string inputLower)
        {
            string[] prefixes = { "add task", "add a task", "create task" };
            foreach (var prefix in prefixes)
            {
                int idx = inputLower.IndexOf(prefix);
                if (idx >= 0)
                {
                    string after = inputLower.Substring(idx + prefix.Length).Trim();
                    if (after.StartsWith("-"))
                        after = after.Substring(1).Trim();
                    return after;
                }
            }
            return null;
        }

        private void HandleAddReminder(string input)
        {
            string lower = input.ToLower();
            int remindIdx = lower.IndexOf("remind me to");
            if (remindIdx < 0)
                remindIdx = lower.IndexOf("add a reminder to");

            if (remindIdx < 0)
            {
                AppendText("CyberGuardian: Sorry, I couldn't find a reminder phrase.", Color.Red);
                return;
            }

            string reminderPart = input.Substring(remindIdx + (lower.Contains("remind me to") ? 12 : 16)).Trim();

            DateTime? reminderDate = null;
            string taskTitle = reminderPart;

            if (reminderPart.EndsWith(" tomorrow", StringComparison.OrdinalIgnoreCase))
            {
                reminderDate = DateTime.Now.AddDays(1);
                taskTitle = reminderPart.Substring(0, reminderPart.Length - " tomorrow".Length).Trim();
            }
            else if (reminderPart.StartsWith("in "))
            {
                string[] parts = reminderPart.Substring(3).Split(' ', StringSplitOptions.RemoveEmptyEntries);
                if (parts.Length >= 2 && int.TryParse(parts[0], out int amount))
                {
                    string unit = parts[1].ToLower();
                    reminderDate = unit switch
                    {
                        "day" or "days" => DateTime.Now.AddDays(amount),
                        "week" or "weeks" => DateTime.Now.AddDays(amount * 7),
                        _ => null
                    };
                    taskTitle = null;
                }
            }

            if (taskTitle != null && !string.IsNullOrWhiteSpace(taskTitle))
            {
                AddTaskFlow("add task - " + taskTitle).Wait();
            }
            if (reminderDate.HasValue)
            {
                LogAction($"Reminder set via NLP command for '{taskTitle ?? "unknown task"}' on {reminderDate.Value.ToShortDateString()}");
                AppendText($"CyberGuardian: Got it! I�ll remind you on {reminderDate.Value.ToShortDateString()}.", Color.Green);
            }
            else
            {
                AppendText("CyberGuardian: Reminder noted without specific time.", Color.Green);
            }
        }

        private async Task AddTaskFlow(string input)
        {
            if (string.IsNullOrWhiteSpace(input) || !input.ToLower().StartsWith("add task -"))
            {
                AppendText("CyberGuardian: Please follow the format 'Add task - [Title]'. Try again.", Color.Red);
                return;
            }

            string title = input.Substring("add task -".Length).Trim();

            string defaultDescription = "Review your account privacy settings to ensure your data is protected.";

            string description = title.ToLower() switch
            {
                string t when t.Contains("privacy") => defaultDescription,
                string t when t.Contains("password") => "Update your passwords and ensure they are strong and unique.",
                string t when t.Contains("2fa") || t.Contains("two-factor") => "Set up two-factor authentication for added security.",
                string t when t.Contains("phishing") => "Learn how to identify and report phishing emails.",
                _ => $"Task: {title} - Please stay cyber-aware."
            };

            AppendText($"CyberGuardian: Task added with the description: \"{description}\".", Color.Yellow);

            AppendText("CyberGuardian: Would you like a reminder? (e.g., Remind me in 3 days)", Color.Yellow);
            string reminderInput = await GetUserInputAsync();

            DateTime? reminderDate = null;

            if (!string.IsNullOrWhiteSpace(reminderInput) && reminderInput.ToLower().Contains("remind me"))
            {
                string reminderText = reminderInput.ToLower().Replace("remind me in", "").Trim();
                string[] parts = reminderText.Split(' ', StringSplitOptions.RemoveEmptyEntries);

                if (parts.Length >= 2 && int.TryParse(parts[0], out int amount))
                {
                    string unit = parts[1];
                    reminderDate = unit switch
                    {
                        "day" or "days" => DateTime.Now.AddDays(amount),
                        "week" or "weeks" => DateTime.Now.AddDays(amount * 7),
                        _ => null
                    };
                }

                if (reminderDate.HasValue)
                {
                    AppendText($"CyberGuardian: Got it! I�ll remind you in {reminderDate.Value.Subtract(DateTime.Now).Days} days.", Color.Green);
                    LogAction($"Reminder set for task '{title}' on {reminderDate.Value.ToShortDateString()}");
                }
                else
                {
                    AppendText("CyberGuardian: Sorry, I couldn't understand the reminder format.", Color.Red);
                }
            }
            else
            {
                AppendText("CyberGuardian: No reminder set.", Color.Green);
            }

            TaskList.Add(new CyberTask
            {
                Title = title,
                Description = description,
                ReminderDate = reminderDate
            });

            LogAction($"Task added: '{title}'");
        }

        private void ShowTasks()
        {
            AppendText("\nYour Cybersecurity Tasks:", Color.Blue);

            if (TaskList.Count == 0)
            {
                AppendText("CyberGuardian: You have no tasks at the moment.", Color.Blue);
            }
            else
            {
                foreach (var task in TaskList)
                {
                    AppendText(task.ToString(), Color.Blue);
                }
            }
        }

        private void LogAction(string actionDescription)
        {
            string timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            ActivityLog.Add($"[{timestamp}] {actionDescription}");

            if (ActivityLog.Count > 10)
                ActivityLog.RemoveAt(0);
        }

        private void ShowActivityLog()
        {
            AppendText("\nActivity Log (Last 10 Actions):", Color.DarkGray);

            if (ActivityLog.Count == 0)
            {
                AppendText("CyberGuardian: No actions recorded yet.", Color.Red);
                return;
            }

            for (int i = 0; i < ActivityLog.Count; i++)
            {
                AppendText($"{i + 1}. {ActivityLog[i]}", Color.DarkGray);
            }
        }

        // ----- CYBERSECURITY QUIZ -----
        class QuizQuestion
        {
            public string Question { get; set; }
            public string[] Options { get; set; }
            public char CorrectOption { get; set; }
            public string Explanation { get; set; }
        }

        private async Task StartCyberQuiz()
        {
            var questions = new List<QuizQuestion>
            {
                new QuizQuestion
                {
                    Question = "What should you do if you receive an email asking for your password?",
                    Options = new[] { "Reply with your password", "Delete the email", "Report the email as phishing", "Ignore it" },
                    CorrectOption = 'C',
                    Explanation = "Reporting phishing emails helps prevent scams and protects others."
                },
                new QuizQuestion
                {
                    Question = "True or False: Using the same password for every account is safe.",
                    Options = new[] { "True", "False" },
                    CorrectOption = 'B',
                    Explanation = "False! Reusing passwords increases risk if one account is breached."
                },
                new QuizQuestion
                {
                    Question = "Which is a strong password example?",
                    Options = new[] { "123456", "Password!", "Winter2025$", "qwerty" },
                    CorrectOption = 'C',
                    Explanation = "\"Winter2025$\" includes uppercase, numbers, and a special character � good job!"
                },
                new QuizQuestion
                {
                    Question = "What does 2FA stand for?",
                    Options = new[] { "Two-Factor Authentication", "Two-Firewall Access", "Two-Factor Access", "Twice-Filtered Authentication" },
                    CorrectOption = 'A',
                    Explanation = "2FA adds an extra layer of security � always enable it when possible."
                },
                new QuizQuestion
                {
                    Question = "Which site is safer to enter personal information?",
                    Options = new[] { "http://example.com", "https://example.com" },
                    CorrectOption = 'B',
                    Explanation = "HTTPS encrypts your data, making it safer from interception."
                },
                new QuizQuestion
                {
                    Question = "What is a common sign of a phishing website?",
                    Options = new[] { "The site loads slowly", "The URL has strange characters or misspellings", "It uses bright colors", "It has no images" },
                    CorrectOption = 'B',
                    Explanation = "Phishing sites often mimic real sites but have suspicious or slightly altered URLs."
                },
                new QuizQuestion
                {
                    Question = "Why should you avoid using public Wi-Fi for sensitive transactions?",
                    Options = new[] { "Public Wi-Fi is always slow", "You might lose your signal", "It can be intercepted by attackers", "It drains battery faster" },
                    CorrectOption = 'C',
                    Explanation = "Attackers can intercept unencrypted traffic on public Wi-Fi and steal your information."
                },
                new QuizQuestion
                {
                    Question = "What is a secure way to store passwords?",
                    Options = new[] { "In a notebook", "In plain text on your computer", "Using a password manager", "By memorizing 20 different passwords" },
                    CorrectOption = 'C',
                    Explanation = "Password managers securely store and encrypt your passwords for easy and safe access."
                },
                new QuizQuestion
                {
                    Question = "Which of the following is an example of two-factor authentication?",
                    Options = new[] { "Typing your password", "Answering a security question", "Receiving a code on your phone", "Using a CAPTCHA" },
                    CorrectOption = 'C',
                    Explanation = "2FA adds a second step, such as a code sent to your phone, after entering your password."
                },
                new QuizQuestion
                {
                    Question = "What is the safest action when receiving an unexpected file from a coworker?",
                    Options = new[] { "Open it immediately", "Reply asking what it is", "Scan it with antivirus first", "Forward it to another colleague" },
                    CorrectOption = 'C',
                    Explanation = "Always scan unexpected attachments for malware before opening, even from known contacts."
                }
            };

            int score = 0;

            AppendText("\nCybersecurity Quiz Time!", Color.DarkCyan);
            AppendText("CyberGuardian: Let's begin! Answer each question by typing A, B, C, or D (or T/F).", Color.DarkCyan);

            for (int i = 0; i < questions.Count; i++)
            {
                var q = questions[i];

                AppendText($"\nQuestion {i + 1}: {q.Question}", Color.Yellow);

                for (int optIndex = 0; optIndex < q.Options.Length; optIndex++)
                {
                    char label = (char)('A' + optIndex);
                    AppendText($"{label}) {q.Options[optIndex]}", Color.Yellow);
                }

                AppendText("Your answer:", Color.White);

                string answer = await GetUserInputAsync();

                if (string.IsNullOrWhiteSpace(answer))
                {
                    AppendText("CyberGuardian: You didn't enter an answer. Let's skip to the next one.", Color.Red);
                    continue;
                }

                char answerChar = char.ToUpper(answer[0]);

                if (answerChar == q.CorrectOption)
                {
                    AppendText("CyberGuardian: Correct! " + q.Explanation, Color.Green);
                    score++;
                }
                else
                {
                    AppendText($"CyberGuardian: Oops! That�s not right. {q.Explanation}", Color.Red);
                }
            }

            AppendText("\nQuiz Complete", Color.Cyan);
            AppendText($"CyberGuardian: You got {score} out of {questions.Count} correct!", Color.Cyan);

            if (score == questions.Count)
                AppendText("CyberGuardian: Great job! You're a cybersecurity pro!", Color.Cyan);
            else if (score >= 3)
                AppendText("CyberGuardian: Nice! You�re on the right track. Keep learning to stay safe.", Color.Cyan);
            else
                AppendText("CyberGuardian: Keep practicing � knowledge is your best defense!", Color.Cyan);
        }

        // ----- HELPER UI METHODS -----
        private async Task<string> GetUserInputAsync()
        {
            var tcs = new TaskCompletionSource<string>();

            void handler(object sender, EventArgs e)
            {
                if (!string.IsNullOrWhiteSpace(txtInput.Text))
                {
                    string input = txtInput.Text.Trim();
                    txtInput.Clear();
                    AppendText($"You: {input}", Color.LightBlue);
                    btnSend.Click -= handler;
                    tcs.SetResult(input);
                }
            }

            btnSend.Click += handler;

            return await tcs.Task;
        }

        private void AppendText(string text, Color color)
        {
            if (chatBox.InvokeRequired)
            {
                chatBox.Invoke(new Action(() => AppendText(text, color)));
                return;
            }

            chatBox.SelectionStart = chatBox.TextLength;
            chatBox.SelectionLength = 0;
            chatBox.SelectionColor = color;
            chatBox.AppendText(text + Environment.NewLine);
            chatBox.SelectionColor = chatBox.ForeColor;
            chatBox.ScrollToCaret();
        }

        private async Task AppendTextWithDelay(string text, Color color, int delay = 15)
        {
            if (chatBox.InvokeRequired)
            {
                await Task.Factory.StartNew(() => AppendTextWithDelay(text, color, delay)).Unwrap();
                return;
            }

            chatBox.SelectionStart = chatBox.TextLength;
            chatBox.SelectionLength = 0;
            chatBox.SelectionColor = color;

            foreach (char c in text)
            {
                chatBox.AppendText(c.ToString());
                chatBox.ScrollToCaret();
                await Task.Delay(delay);
            }

            chatBox.AppendText(Environment.NewLine);
            chatBox.SelectionColor = chatBox.ForeColor;
        }

        private void ShowWelcomeMessage()
        {
            AppendText("CyberGuardian: Hello! I'm your cybersecurity assistant. You can ask me questions, manage tasks, or start a quiz.", Color.Magenta);
            AppendText("Try typing commands like:\n- Add task - Update my password\n- Start quiz\n- Show tasks\n- Show activity log", Color.Magenta);
        }
    }

    // ----- DATA MODELS -----
    class CyberTask
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime? ReminderDate { get; set; }
        public override string ToString()
        {
            string reminderInfo = ReminderDate.HasValue ? $" (Reminder: {ReminderDate.Value.ToShortDateString()})" : "";
            return $"- {Title}: {Description}{reminderInfo}";
        }
    }
}
