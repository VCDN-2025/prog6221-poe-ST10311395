﻿namespace CyberGuardianGUI1
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.RichTextBox chatBox;
        private System.Windows.Forms.TextBox txtInput;
        private System.Windows.Forms.Button btnSend;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.chatBox = new System.Windows.Forms.RichTextBox();
            this.txtInput = new System.Windows.Forms.TextBox();
            this.btnSend = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // chatBox
            // 
            this.chatBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chatBox.Location = new System.Drawing.Point(0, 0);
            this.chatBox.Name = "chatBox";
            this.chatBox.ReadOnly = true;
            this.chatBox.Size = new System.Drawing.Size(800, 390);
            this.chatBox.TabIndex = 0;
            this.chatBox.Text = "";
            // 
            // txtInput
            // 
            this.txtInput.Location = new System.Drawing.Point(0, 393);  // position below chatBox
            this.txtInput.Name = "txtInput";
            this.txtInput.Size = new System.Drawing.Size(720, 22);
            this.txtInput.TabIndex = 1;
            // 
            // btnSend
            // 
            this.btnSend.Location = new System.Drawing.Point(720, 393);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(80, 22);
            this.btnSend.TabIndex = 2;
            this.btnSend.Text = "Send";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // Add controls to the Form
            //
            this.Controls.Add(this.chatBox);
            this.Controls.Add(this.txtInput);
            this.Controls.Add(this.btnSend);
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(800, 420);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CyberGuardian ChatBot";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

    }
}
